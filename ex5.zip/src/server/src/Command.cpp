//
// class of Command.cpp
//
#include "Command.h"
Command::Command() {
}
Command::~Command() {}