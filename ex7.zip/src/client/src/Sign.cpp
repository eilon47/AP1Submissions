/**
 * Sign source file.
 */
#include "Sign.h"
//Sets sign.
void Sign::setSign(SIGN s) {
    this->sign = s;
}
//Returns sign.
SIGN Sign::getSign() {
    return this->sign;
}