//
// Class of Task- abstract
//

#include "Task.h"
